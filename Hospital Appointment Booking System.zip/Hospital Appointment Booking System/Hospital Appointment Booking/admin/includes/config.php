<?php
date_default_timezone_set('Europe/Dublin');
$con=mysqli_connect("localhost","root","","hospitaldb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
